declare const Loader: () => JSX.Element;
export default Loader;
