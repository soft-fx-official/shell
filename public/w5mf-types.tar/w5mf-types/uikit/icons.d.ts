export * from './dts/icons/index';
export { default } from './dts/icons/index';